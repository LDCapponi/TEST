// Artboards for Sketch2Fly visual direction exploration
// Brand DNA from real logos: deep teal #1F4D5C, bright teal #2F8F9D,
// slate #8A8E91, ink #1F2426, paper #FFFFFF / #F4F5F6.
// Type: Chakra Petch (chamfered, mechanical) + JetBrains Mono.

const C = {
  paper: '#FFFFFF',
  paperWarm: '#F4F5F6',
  ink: '#1F2426',
  inkSoft: '#2C3438',
  tealDeep: '#1F4D5C',
  teal: '#2F8F9D',
  tealLight: '#5FB8C4',
  slate: '#8A8E91',
  slateLight: '#C9CDD0',
  rule: 'rgba(31,36,38,0.16)',
  ruleSoft: 'rgba(31,36,38,0.08)',
  mute: 'rgba(31,36,38,0.55)',
};

const FONT_DISPLAY = '"Chakra Petch", "Rajdhani", "Inter Tight", sans-serif';
const FONT_MONO = '"JetBrains Mono", ui-monospace, monospace';

const Borrador = ({ label, w = '100%', h = 200, tone = 'light' }) => {
  const bg = tone === 'dark' ? '#0E1518' : '#ECEEF0';
  const stripe = tone === 'dark' ? 'rgba(255,255,255,0.04)' : 'rgba(31,36,38,0.05)';
  const text = tone === 'dark' ? 'rgba(232,236,238,0.7)' : 'rgba(31,36,38,0.55)';
  const border = tone === 'dark' ? 'rgba(255,255,255,0.10)' : 'rgba(31,36,38,0.14)';
  return (
    <div style={{
      width: w, height: h, background: bg,
      backgroundImage: `repeating-linear-gradient(135deg, ${stripe} 0 1px, transparent 1px 12px)`,
      border: `1px solid ${border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: FONT_MONO, fontSize: 10,
      color: text, letterSpacing: '0.1em', textTransform: 'uppercase',
      position: 'relative', overflow: 'hidden', whiteSpace: 'pre-line', textAlign: 'center',
    }}>
      <span style={{ position: 'absolute', top: 8, left: 10, fontSize: 9, opacity: 0.5 }}>BORRADOR</span>
      <span style={{ position: 'absolute', top: 8, right: 10, fontSize: 9, opacity: 0.5 }}>[ MEDIA ]</span>
      <span style={{ padding: '0 16px', lineHeight: 1.6 }}>{label}</span>
      <Tick pos="tl" tone={tone} /><Tick pos="tr" tone={tone} />
      <Tick pos="bl" tone={tone} /><Tick pos="br" tone={tone} />
    </div>
  );
};
const Tick = ({ pos, tone }) => {
  const c = tone === 'dark' ? 'rgba(232,236,238,0.4)' : 'rgba(31,36,38,0.35)';
  const s = { position: 'absolute', width: 10, height: 10 };
  if (pos === 'tl') Object.assign(s, { top: 0, left: 0, borderTop: `1px solid ${c}`, borderLeft: `1px solid ${c}` });
  if (pos === 'tr') Object.assign(s, { top: 0, right: 0, borderTop: `1px solid ${c}`, borderRight: `1px solid ${c}` });
  if (pos === 'bl') Object.assign(s, { bottom: 0, left: 0, borderBottom: `1px solid ${c}`, borderLeft: `1px solid ${c}` });
  if (pos === 'br') Object.assign(s, { bottom: 0, right: 0, borderBottom: `1px solid ${c}`, borderRight: `1px solid ${c}` });
  return <div style={s}></div>;
};

// Logo — uses the real wordmark or mark.
const Wordmark = ({ h = 28 }) => (
  <img src="assets/s2f-wordmark.png" alt="Sketch2Fly" style={{ height: h, display: 'block' }} />
);
const Mark = ({ h = 38 }) => (
  <img src="assets/s2f-mark.png" alt="Sketch2Fly" style={{ height: h, display: 'block' }} />
);

// Chamfer corners — visual nod to the logo letterforms.
const chamfer = (size = 10) => ({
  clipPath: `polygon(${size}px 0, 100% 0, 100% calc(100% - ${size}px), calc(100% - ${size}px) 100%, 0 100%, 0 ${size}px)`,
});

// ─────────────────────────────────────────────────────────────
// DIRECTION A — "Atlas": editorial blueprint, dense, light ground
// ─────────────────────────────────────────────────────────────
const DirectionA = () => (
  <div style={{
    width: 1400, height: 900, background: C.paper, color: C.ink,
    fontFamily: FONT_DISPLAY, position: 'relative', overflow: 'hidden',
    display: 'flex', flexDirection: 'column',
  }}>
    {/* top bar */}
    <div style={{
      height: 60, borderBottom: `1px solid ${C.rule}`,
      display: 'grid', gridTemplateColumns: '1fr auto 1fr',
      alignItems: 'center', padding: '0 28px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <Wordmark h={26} />
      </div>
      <nav style={{ display: 'flex', gap: 28, color: C.mute, fontSize: 13, fontWeight: 500, letterSpacing: '0.02em', textTransform: 'uppercase' }}>
        <span style={{ color: C.ink }}>Practice</span>
        <span>Platforms</span>
        <span>Capabilities</span>
        <span>Academy</span>
        <span>Lab</span>
        <span>Journal</span>
      </nav>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', alignItems: 'center', fontFamily: FONT_MONO, fontSize: 11, color: C.mute }}>
        <span>09:42 · UTC-6</span>
        <span style={{ padding: '5px 9px', border: `1px solid ${C.rule}`, color: C.ink }}>EN</span>
        <span style={{ padding: '5px 9px', color: C.mute }}>ES</span>
        <span style={{ background: C.tealDeep, color: '#fff', padding: '9px 14px', fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase', ...chamfer(8) }}>
          Mission brief →
        </span>
      </div>
    </div>

    {/* body */}
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '64px 1fr 360px', minHeight: 0 }}>
      {/* left rail */}
      <div style={{
        borderRight: `1px solid ${C.rule}`,
        fontFamily: FONT_MONO, fontSize: 10, color: C.mute,
        display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'space-between',
        padding: '20px 0', letterSpacing: '0.18em',
      }}>
        <div style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}>
          DOC · S2F-MFG-001 · REV 04 · 26.04.26
        </div>
        <div style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)', color: C.teal }}>
          CRC · 09.928°N · 84.090°W
        </div>
      </div>

      {/* center */}
      <div style={{ padding: '44px 52px', display: 'flex', flexDirection: 'column', gap: 28 }}>
        <div style={{ fontFamily: FONT_MONO, fontSize: 11, letterSpacing: '0.22em', color: C.teal, textTransform: 'uppercase' }}>
          01 — A Central American aerospace practice
        </div>
        <h1 style={{
          margin: 0, fontSize: 96, lineHeight: 0.94,
          letterSpacing: '-0.025em', fontWeight: 600, textWrap: 'balance',
        }}>
          From sketch <span style={{ color: C.teal, fontWeight: 500, fontStyle: 'italic' }}>to flight</span>,<br />
          engineered in<br />Costa&nbsp;Rica.
        </h1>
        <p style={{ margin: 0, maxWidth: 600, fontSize: 17, lineHeight: 1.5, color: 'rgba(31,36,38,0.7)' }}>
          We design, build, integrate and operate utility unmanned
          aerial vehicles — tailored to each mission, sized for
          each client. One workshop, the full lifecycle.
        </p>
        <div style={{ display: 'flex', gap: 14, marginTop: 8 }}>
          <button style={{
            background: C.tealDeep, color: '#fff', border: 'none',
            padding: '15px 26px', fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase',
            fontFamily: FONT_DISPLAY, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 12, ...chamfer(10),
          }}>
            Request a mission brief <span style={{ fontFamily: FONT_MONO }}>→</span>
          </button>
          <button style={{
            background: 'transparent', color: C.ink,
            border: `1px solid ${C.rule}`, padding: '15px 26px', fontSize: 13,
            letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: FONT_DISPLAY, fontWeight: 600,
            cursor: 'pointer', ...chamfer(10),
          }}>Our capabilities</button>
        </div>
        <div style={{
          marginTop: 'auto', display: 'grid', gridTemplateColumns: 'repeat(4,1fr)',
          borderTop: `1px solid ${C.rule}`, paddingTop: 20,
          fontFamily: FONT_MONO, fontSize: 11, color: C.mute, letterSpacing: '0.08em',
        }}>
          <Stat k="DESIGN" v="MISSION-TAILORED" />
          <Stat k="MFG" v="IN-HOUSE STRUCTURES" />
          <Stat k="OPS" v="TRAIN · CERTIFY · FLY" />
          <Stat k="LIFECYCLE" v="END-TO-END" />
        </div>
      </div>

      {/* right plate */}
      <div style={{ borderLeft: `1px solid ${C.rule}`, display: 'flex', flexDirection: 'column' }}>
        <div style={{
          padding: '14px 18px', fontFamily: FONT_MONO, fontSize: 10,
          letterSpacing: '0.18em', color: C.mute,
          borderBottom: `1px solid ${C.ruleSoft}`,
          display: 'flex', justifyContent: 'space-between',
        }}>
          <span>FIG. 01</span><span>ISO · EXPLODED</span>
        </div>
        <div style={{ flex: 1, padding: 18, position: 'relative' }}>
          <Borrador label={"SOLIDWORKS\nVISUALIZE\nEXPLODED ANIMATION"} h="100%" />
          {/* mark watermark */}
          <div style={{ position: 'absolute', bottom: 28, right: 28, opacity: 0.85 }}>
            <Mark h={48} />
          </div>
        </div>
        <div style={{ padding: '14px 18px', fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em', color: C.mute, borderTop: `1px solid ${C.ruleSoft}` }}>
          S2F-X1 / 142 PARTS / 1.84 KG
        </div>
      </div>
    </div>

    <div style={{
      borderTop: `1px solid ${C.rule}`, padding: '14px 28px',
      fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em', color: C.mute,
      display: 'flex', justifyContent: 'space-between',
    }}>
      <span>SKETCH2FLY · UTILITY DRONES · CR</span>
      <span>EST. 2026 · SAN JOSÉ</span>
      <span>↓ SCROLL · CAPABILITIES</span>
    </div>
  </div>
);

const Stat = ({ k, v }) => (
  <div>
    <div style={{ opacity: 0.55, fontSize: 9, marginBottom: 4 }}>{k}</div>
    <div style={{ color: C.ink }}>{v}</div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// DIRECTION B — "Hangar": dark, blueprint, schematic plan view
// Now: deep teal blueprint instead of green/sand.
// ─────────────────────────────────────────────────────────────
const DirectionB = () => (
  <div style={{
    width: 1400, height: 900, background: '#0B1518', color: '#E8ECEE',
    fontFamily: FONT_DISPLAY, position: 'relative', overflow: 'hidden',
    display: 'flex', flexDirection: 'column',
  }}>
    <div style={{
      position: 'absolute', inset: 0, pointerEvents: 'none',
      backgroundImage: `linear-gradient(rgba(95,184,196,0.06) 1px, transparent 1px),linear-gradient(90deg, rgba(95,184,196,0.06) 1px, transparent 1px)`,
      backgroundSize: '40px 40px',
    }}></div>

    <div style={{
      height: 60, borderBottom: `1px solid rgba(232,236,238,0.12)`,
      display: 'grid', gridTemplateColumns: '1fr auto 1fr',
      alignItems: 'center', padding: '0 28px',
      position: 'relative', zIndex: 2,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {/* light wordmark — invert */}
        <img src="assets/s2f-wordmark.png" alt="Sketch2Fly" style={{ height: 26, display: 'block', filter: 'brightness(0) invert(1)' }} />
      </div>
      <nav style={{ display: 'flex', gap: 28, color: 'rgba(232,236,238,0.6)', fontSize: 13, fontWeight: 500, letterSpacing: '0.02em', textTransform: 'uppercase' }}>
        <span style={{ color: '#E8ECEE' }}>Platforms</span>
        <span>Capabilities</span>
        <span>Industries</span>
        <span>Academy</span>
        <span>Workshop</span>
        <span>News</span>
      </nav>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end', alignItems: 'center', fontFamily: FONT_MONO, fontSize: 11, color: 'rgba(232,236,238,0.6)' }}>
        <span>09.928°N 84.090°W</span>
        <span style={{ padding: '5px 9px', border: `1px solid rgba(232,236,238,0.22)`, color: '#E8ECEE' }}>EN</span>
        <span style={{ padding: '5px 9px' }}>ES</span>
      </div>
    </div>

    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', minHeight: 0, position: 'relative', zIndex: 2 }}>
      <div style={{ padding: '70px 60px', display: 'flex', flexDirection: 'column', gap: 28, justifyContent: 'center' }}>
        <div style={{
          display: 'inline-flex', alignSelf: 'flex-start', alignItems: 'center', gap: 10,
          padding: '7px 14px', border: `1px solid rgba(95,184,196,0.5)`,
          color: C.tealLight, fontFamily: FONT_MONO,
          fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', ...chamfer(7),
        }}>
          <span style={{ width: 6, height: 6, background: C.tealLight, borderRadius: '50%' }}></span>
          Engineering practice · est. 2026
        </div>
        <h1 style={{
          margin: 0, fontSize: 92, lineHeight: 0.94, fontWeight: 600,
          letterSpacing: '-0.03em', textWrap: 'balance',
        }}>
          Utility unmanned<br />
          systems, <span style={{ color: C.tealLight, fontStyle: 'italic', fontWeight: 500 }}>responsibly</span> built.
        </h1>
        <p style={{ margin: 0, maxWidth: 540, fontSize: 17, lineHeight: 1.5, color: 'rgba(232,236,238,0.7)' }}>
          A vertically-integrated UAV practice in Costa Rica.
          Mission-tailored design, in-house manufacturing, full
          operations support — through to certified
          decommissioning of every airframe we put in the air.
        </p>
        <div style={{ display: 'flex', gap: 14, marginTop: 8 }}>
          <button style={{
            background: C.teal, color: '#0B1518', border: 'none',
            padding: '16px 26px', fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase',
            fontFamily: FONT_DISPLAY, fontWeight: 700, cursor: 'pointer', ...chamfer(10),
          }}>Request a mission brief →</button>
          <button style={{
            background: 'transparent', color: '#E8ECEE',
            border: `1px solid rgba(232,236,238,0.3)`,
            padding: '16px 26px', fontSize: 13, letterSpacing: '0.08em', textTransform: 'uppercase',
            fontFamily: FONT_DISPLAY, fontWeight: 600, cursor: 'pointer', ...chamfer(10),
          }}>Platforms</button>
        </div>
      </div>

      <div style={{
        borderLeft: `1px solid rgba(232,236,238,0.12)`,
        position: 'relative', display: 'flex', flexDirection: 'column',
      }}>
        <div style={{
          padding: '14px 18px', display: 'flex', justifyContent: 'space-between',
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em',
          color: 'rgba(232,236,238,0.55)', borderBottom: `1px solid rgba(232,236,238,0.08)`,
        }}>
          <span>FIG. 01 · PLAN VIEW</span>
          <span>S2F-X1 · QUAD · MISSION-TAILORED</span>
        </div>
        <div style={{ flex: 1, padding: 24, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <SchematicPlaceholder />
        </div>
        <div style={{
          padding: '14px 18px', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)',
          fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.14em',
          color: 'rgba(232,236,238,0.55)', borderTop: `1px solid rgba(232,236,238,0.08)`,
        }}>
          <Stat2 k="WINGSPAN" v="980 MM" />
          <Stat2 k="MTOW" v="2.4 KG" />
          <Stat2 k="ENDURANCE" v="48 MIN" />
        </div>
      </div>
    </div>
  </div>
);

const Stat2 = ({ k, v }) => (
  <div>
    <div style={{ opacity: 0.6, fontSize: 9, marginBottom: 3 }}>{k}</div>
    <div style={{ color: '#E8ECEE' }}>{v}</div>
  </div>
);

const SchematicPlaceholder = () => (
  <div style={{ position: 'relative', width: '100%', height: '100%', maxWidth: 540, maxHeight: 540 }}>
    <svg viewBox="0 0 540 540" style={{ width: '100%', height: '100%' }}>
      <defs>
        <pattern id="hatch2" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)">
          <line x1="0" y1="0" x2="0" y2="6" stroke="rgba(95,184,196,0.18)" strokeWidth="1" />
        </pattern>
      </defs>
      <circle cx="270" cy="270" r="240" fill="none" stroke="rgba(95,184,196,0.18)" strokeDasharray="2 4" />
      <circle cx="270" cy="270" r="180" fill="none" stroke="rgba(95,184,196,0.22)" />
      <circle cx="270" cy="270" r="120" fill="none" stroke="rgba(95,184,196,0.28)" />
      <circle cx="270" cy="270" r="60" fill="none" stroke="rgba(95,184,196,0.4)" />
      <line x1="0" y1="270" x2="540" y2="270" stroke="rgba(95,184,196,0.12)" />
      <line x1="270" y1="0" x2="270" y2="540" stroke="rgba(95,184,196,0.12)" />
      <rect x="170" y="170" width="200" height="200" fill="url(#hatch2)" stroke="rgba(95,184,196,0.4)" strokeDasharray="4 4" />
      <g fontFamily="JetBrains Mono, monospace" fontSize="10" fill="rgba(232,236,238,0.65)" letterSpacing="0.1em">
        <circle cx="270" cy="170" r="3" fill={C.tealLight} />
        <line x1="270" y1="170" x2="270" y2="120" stroke="rgba(95,184,196,0.5)" />
        <text x="270" y="110" textAnchor="middle">A · ARM N</text>
        <circle cx="370" cy="270" r="3" fill={C.tealLight} />
        <line x1="370" y1="270" x2="430" y2="270" stroke="rgba(95,184,196,0.5)" />
        <text x="438" y="274">B · PAYLOAD BAY</text>
        <circle cx="270" cy="370" r="3" fill={C.tealLight} />
        <line x1="270" y1="370" x2="270" y2="420" stroke="rgba(95,184,196,0.5)" />
        <text x="270" y="436" textAnchor="middle">C · ARM S</text>
        <circle cx="170" cy="270" r="3" fill={C.tealLight} />
        <line x1="170" y1="270" x2="110" y2="270" stroke="rgba(95,184,196,0.5)" />
        <text x="100" y="274" textAnchor="end">D · GIMBAL</text>
      </g>
      <text x="270" y="262" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="10" letterSpacing="0.2em" fill="rgba(232,236,238,0.45)">[ MEDIA ]</text>
      <text x="270" y="280" textAnchor="middle" fontFamily="JetBrains Mono, monospace" fontSize="9" letterSpacing="0.16em" fill="rgba(232,236,238,0.35)">SOLIDWORKS · TOP-DOWN</text>
    </svg>
  </div>
);

// ─────────────────────────────────────────────────────────────
// DIRECTION C — "Field Manual": image-led, big mark watermark
// ─────────────────────────────────────────────────────────────
const DirectionC = () => (
  <div style={{
    width: 1400, height: 900, background: C.paperWarm, color: C.ink,
    fontFamily: FONT_DISPLAY, position: 'relative', overflow: 'hidden',
    display: 'flex', flexDirection: 'column',
  }}>
    <div style={{
      height: 40, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 28px', fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em',
      color: C.mute, borderBottom: `1px solid ${C.ruleSoft}`, background: '#fff',
    }}>
      <span>SKETCH2FLY · FIELD MANUAL · VOL. I</span>
      <span><span style={{ color: C.ink }}>EN</span> · ES</span>
    </div>

    <div style={{
      padding: '20px 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      borderBottom: `1px solid ${C.rule}`, background: '#fff',
    }}>
      <Wordmark h={32} />
      <nav style={{ display: 'flex', gap: 28, fontSize: 14, color: C.mute, fontWeight: 500, letterSpacing: '0.02em', textTransform: 'uppercase' }}>
        <span style={{ color: C.ink }}>Platforms</span>
        <span>Capabilities</span>
        <span>Industries</span>
        <span>Academy</span>
        <span>Workshop</span>
        <span>Lab</span>
        <span>Contact</span>
      </nav>
    </div>

    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '440px 1fr', minHeight: 0 }}>
      <div style={{
        padding: '52px 44px', display: 'flex', flexDirection: 'column', gap: 24,
        borderRight: `1px solid ${C.rule}`, justifyContent: 'space-between', background: '#fff',
      }}>
        <div style={{ fontFamily: FONT_MONO, fontSize: 11, letterSpacing: '0.22em', color: C.teal, textTransform: 'uppercase' }}>
          § 01 · The practice
        </div>
        <div>
          <h2 style={{
            fontSize: 30, lineHeight: 1.18, fontWeight: 500,
            letterSpacing: '-0.012em', margin: 0, textWrap: 'balance',
          }}>
            We design utility unmanned aircraft for the people doing
            careful work — measuring forests, mapping coastlines,
            inspecting power lines, answering emergencies.
          </h2>
          <p style={{ marginTop: 22, fontSize: 14, lineHeight: 1.65, color: C.mute, maxWidth: 380 }}>
            Every airframe is mission-tailored and built in-house
            from the structure up. We stay with the aircraft
            through training, certification, repair and the
            quiet end of its working life.
          </p>
        </div>
        <div style={{ fontFamily: FONT_MONO, fontSize: 10, color: C.mute, letterSpacing: '0.14em', borderTop: `1px solid ${C.ruleSoft}`, paddingTop: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span>SAN JOSÉ · CRC</span><span>09:42 UTC-6</span>
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <span style={{ background: C.tealDeep, color: '#fff', padding: '11px 18px', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: FONT_DISPLAY, fontWeight: 600, ...chamfer(8) }}>
              Brief us →
            </span>
            <span style={{ border: `1px solid ${C.rule}`, color: C.ink, padding: '11px 18px', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', fontFamily: FONT_DISPLAY, fontWeight: 600, ...chamfer(8) }}>
              Lab notes
            </span>
          </div>
        </div>
      </div>

      <div style={{ position: 'relative' }}>
        <div style={{ position: 'absolute', inset: 28, display: 'flex', flexDirection: 'column' }}>
          <div style={{ flex: 1 }}>
            <Borrador label={"SOLIDWORKS VISUALIZE\n3/4 RENDER · MATTE\nTEAL WORKSHOP BG"} h="100%" />
          </div>
          <div style={{
            marginTop: 14, display: 'flex', justifyContent: 'space-between',
            fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.16em', color: C.mute,
          }}>
            <span>PLATE 01 · S2F-X1 / 3-QUARTER</span>
            <span>↓ THE PRACTICE</span>
          </div>
        </div>
        {/* huge faint mark watermark */}
        <div style={{ position: 'absolute', right: -80, bottom: -80, opacity: 0.06, pointerEvents: 'none' }}>
          <Mark h={620} />
        </div>
      </div>
    </div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// LIFECYCLE DIAGRAM PREVIEW
// ─────────────────────────────────────────────────────────────
const LifecycleArtboard = () => {
  const stages = [
    { n: '01', t: 'Concept', es: 'Concepto', d: 'Mission-driven scoping with the client.' },
    { n: '02', t: 'Design', es: 'Diseño', d: 'Aero & systems engineering, in-house.' },
    { n: '03', t: 'Manufacture', es: 'Fabricación', d: 'Composite & printed structures.' },
    { n: '04', t: 'Integration', es: 'Integración', d: 'Avionics, payloads, calibration.' },
    { n: '05', t: 'Operate', es: 'Operación', d: 'Training, certification, flight ops.' },
    { n: '06', t: 'Sustain', es: 'Mantener', d: 'Repair, spares, workshop service.' },
    { n: '07', t: 'Retire', es: 'Retirar', d: 'Recovery & responsible end-of-life.' },
  ];
  return (
    <div style={{
      width: 1400, height: 720, background: C.paper, color: C.ink,
      fontFamily: FONT_DISPLAY, position: 'relative',
      display: 'flex', flexDirection: 'column', borderTop: `1px solid ${C.rule}`,
    }}>
      <div style={{ padding: '32px 48px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: `1px solid ${C.ruleSoft}` }}>
        <div>
          <div style={{ fontFamily: FONT_MONO, fontSize: 11, letterSpacing: '0.22em', color: C.teal, marginBottom: 8 }}>§ 03 · LIFECYCLE</div>
          <h2 style={{ margin: 0, fontSize: 46, letterSpacing: '-0.022em', fontWeight: 600 }}>
            Seven stages. One workshop.
          </h2>
        </div>
        <div style={{ fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em', color: C.mute, textAlign: 'right' }}>
          INTERACTION · HOVER A STAGE<br />FOR DETAIL · {' '}
          <span style={{ color: C.teal }}>● 02 — DESIGN</span>
        </div>
      </div>

      <div style={{ flex: 1, padding: '40px 48px 32px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <div style={{ position: 'relative', height: 240 }}>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 110, height: 1, background: C.rule }}></div>
          <div style={{
            position: 'absolute', left: 0, right: 0, top: 110, height: 1,
            background: `linear-gradient(90deg, ${C.tealDeep} 0%, ${C.teal} 28%, transparent 28%)`,
          }}></div>

          {stages.map((s, i) => {
            const left = `${(i / (stages.length - 1)) * 100}%`;
            const active = i === 1;
            return (
              <div key={s.n} style={{
                position: 'absolute', left, top: 0, transform: 'translateX(-50%)',
                width: 170, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
              }}>
                <div style={{ fontFamily: FONT_MONO, fontSize: 10, color: active ? C.teal : C.mute, letterSpacing: '0.18em' }}>{s.n}</div>
                <div style={{
                  width: active ? 18 : 10, height: active ? 18 : 10,
                  background: active ? C.teal : C.paper,
                  border: `1.5px solid ${active ? C.teal : C.ink}`,
                  marginTop: active ? 26 : 30,
                  boxShadow: active ? `0 0 0 6px rgba(47,143,157,0.18)` : 'none',
                  transform: 'rotate(45deg)', // diamond marker — chamfer language
                }}></div>
                <div style={{
                  textAlign: 'center', marginTop: 18, fontWeight: active ? 700 : 600,
                  fontSize: 17, letterSpacing: '-0.01em',
                  color: active ? C.ink : 'rgba(31,36,38,0.85)',
                }}>{s.t}</div>
                <div style={{ fontFamily: FONT_MONO, fontSize: 9, color: C.mute, letterSpacing: '0.14em', marginTop: -8 }}>{s.es.toUpperCase()}</div>
                <div style={{ fontSize: 11.5, color: C.mute, textAlign: 'center', lineHeight: 1.45, padding: '0 6px', maxWidth: 160, opacity: active ? 1 : 0.7 }}>{s.d}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// CONFIGURATOR PREVIEW
// ─────────────────────────────────────────────────────────────
const ConfiguratorArtboard = () => (
  <div style={{
    width: 1400, height: 800, background: C.paper, color: C.ink,
    fontFamily: FONT_DISPLAY, display: 'flex', flexDirection: 'column',
    borderTop: `1px solid ${C.rule}`,
  }}>
    <div style={{ padding: '32px 48px 16px', borderBottom: `1px solid ${C.ruleSoft}` }}>
      <div style={{ fontFamily: FONT_MONO, fontSize: 11, letterSpacing: '0.22em', color: C.teal, marginBottom: 8 }}>§ 05 · CONFIGURATOR</div>
      <h2 style={{ margin: 0, fontSize: 46, letterSpacing: '-0.022em', fontWeight: 600 }}>
        Tell us the mission. We sketch the aircraft.
      </h2>
    </div>

    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '380px 1fr 380px', minHeight: 0 }}>
      <div style={{ borderRight: `1px solid ${C.ruleSoft}`, padding: '28px 32px', display: 'flex', flexDirection: 'column', gap: 24 }}>
        <CfgGroup label="A · MISSION" options={['Survey & mapping', 'Inspection', 'Emergency response', 'Research payload']} active={0} />
        <CfgGroup label="B · ENVIRONMENT" options={['Tropical lowland', 'Highland / cloud forest', 'Coastal / marine', 'Urban']} active={2} />
        <CfgGroup label="C · ENDURANCE" options={['< 30 min', '30–60 min', '60–120 min', '120+ min']} active={2} />
        <CfgGroup label="D · PAYLOAD" options={['RGB', 'Multispectral', 'LiDAR', 'Custom science']} active={1} />
      </div>

      <div style={{ padding: 28, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.18em', color: C.mute, display: 'flex', justifyContent: 'space-between' }}>
          <span>S2F-X1 / COASTAL · 90 MIN · MULTISPEC</span>
          <span style={{ color: C.teal }}>● MATCH 94%</span>
        </div>
        <div style={{ flex: 1 }}>
          <Borrador label={"SOLIDWORKS VISUALIZE\nLIVE-UPDATING RENDER\nROTATES WITH MISSION"} h="100%" />
        </div>
      </div>

      <div style={{ borderLeft: `1px solid ${C.ruleSoft}`, padding: '28px 32px', fontFamily: FONT_MONO, fontSize: 11, color: C.ink, display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ fontSize: 10, letterSpacing: '0.22em', color: C.mute }}>RECOMMENDED · S2F-X1</div>
        <div style={{ fontFamily: FONT_DISPLAY, fontSize: 28, fontWeight: 600, letterSpacing: '-0.018em', lineHeight: 1.12 }}>
          Quad · 1.1m wingspan · composite frame
        </div>
        <div style={{ height: 1, background: C.ruleSoft, margin: '4px 0' }}></div>
        {[
          ['MTOW', '2.8 KG'],
          ['ENDURANCE', '92 MIN'],
          ['CRUISE', '14 M/S'],
          ['CEILING', '3 800 M'],
          ['PAYLOAD', 'MULTISPEC · 480 G'],
          ['IP', 'IP54 · COASTAL OK'],
          ['LEAD TIME', '14 WEEKS'],
        ].map(([k, v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11 }}>
            <span style={{ color: C.mute, letterSpacing: '0.16em' }}>{k}</span>
            <span>{v}</span>
          </div>
        ))}
        <div style={{
          marginTop: 'auto', background: C.tealDeep, color: '#fff',
          padding: '15px 20px', fontSize: 12, letterSpacing: '0.08em', textTransform: 'uppercase',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          fontFamily: FONT_DISPLAY, fontWeight: 600, ...chamfer(10),
        }}>
          <span>Send this brief →</span>
          <span style={{ fontFamily: FONT_MONO, fontSize: 10, opacity: 0.75 }}>S2F-BRF-4821</span>
        </div>
      </div>
    </div>
  </div>
);

const CfgGroup = ({ label, options, active }) => (
  <div>
    <div style={{ fontFamily: FONT_MONO, fontSize: 10, letterSpacing: '0.22em', color: C.mute, marginBottom: 12 }}>{label}</div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {options.map((o, i) => (
        <div key={o} style={{
          padding: '11px 14px', fontSize: 13, fontWeight: 500,
          border: `1px solid ${i === active ? C.tealDeep : C.ruleSoft}`,
          background: i === active ? C.tealDeep : 'transparent',
          color: i === active ? '#fff' : C.ink,
          letterSpacing: '-0.005em',
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          ...chamfer(8),
        }}>
          <span>{o}</span>
          {i === active && <span style={{ fontFamily: FONT_MONO, fontSize: 10 }}>●</span>}
        </div>
      ))}
    </div>
  </div>
);

Object.assign(window, {
  DirectionA, DirectionB, DirectionC,
  LifecycleArtboard, ConfiguratorArtboard,
});
